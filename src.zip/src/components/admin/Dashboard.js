import React, { Component } from 'react';
import  './static/css/App.css';
  class Dashboard extends Component {

    render() {

        return (

            <div class="row" className="mb-2 pageheading">

                <div class="col-sm-12 btn btn-primary">

                    Dashboard 

             </div>

            </div>
            

        );

    }

}

export default Dashboard;