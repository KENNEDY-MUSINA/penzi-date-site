
import React, { Component } from 'react';
import axios from 'axios';
import { Button, Card, CardBody, Col, Container, Form, Input, InputGroup, Row } from 'reactstrap';

class Reg extends Component {

  constructor() {

    super();
    this.state = {
      first_name: '',
      last_name: '',
      email: '',
      Password: '',

    }

    this.first_name = this.first_name.bind(this);
    this.last_name = this.last_name.bind(this);
    this.email = this.email.bind(this);
    this.Password = this.Password.bind(this);
    this.register = this.register.bind(this);

  }

  first_name(event) {
    this.setState({ first_name: event.target.value })
  }

  last_name(event) {
    this.setState({ last_name: event.target.value })
  }

  email(event) {
    this.setState({ email: event.target.value })
  }
  Password(event) {
    this.setState({ Password: event.target.value })

  }
 
  register = async (event) => {

    var data = JSON.stringify({
        first_name:this.state.first_name,
        last_name:this.state.last_name,
        email:this.state.email,
        Password:this.state.Password
        })
    var config = {
      method: 'post',
      url: 'http://localhost/penzi-date-site/user.php',
      headers: { 
        'Content-Type': 'application/json',
      },
      data : data
    };
    
    axios(config)
    .then(function (response) {
      console.log(JSON.stringify(response.data));
    })
    .catch(function (error) {
      console.log(error);
    });
    

  }

  render() {
    return (
      <div className="app flex-row align-items-center">

        <Container>

          <Row className="justify-content-center">

            <Col md="9" lg="7" xl="6">

              <Card className="mx-4">

                <CardBody className="p-4">

                  <Form>
                    <div class="row" className="mb-2 pageheading">

                      <div class="col-sm-12 btn btn-primary">

                        Admin Registration

                        </div>

                    </div>

                    <InputGroup className="mb-3">

                      <Input type="text"  onChange={this.first_name} placeholder="Enter first name" />

                    </InputGroup>

                    <InputGroup className="mb-3">

                      <Input type="text"  onChange={this.last_name} placeholder="Last name" />

                    </InputGroup>

                    <InputGroup className="mb-3">

                      <Input type="text"  onChange={this.email} placeholder="Enter email" />

                    </InputGroup>

                    <InputGroup className="mb-4">
                      <Input type="password"  onChange={this.Password} placeholder="Enter password" />
                    </InputGroup>

                    
                    <Button  onClick={this.register}  color="success" block>Register</Button>
                    <p className="Already registered text-right">
                     Already Registered <a href="login">login here</a>
                </p>

                  </Form>

                </CardBody>

              </Card>

            </Col>

          </Row>

        </Container>

      </div>

    );

  }

}
export default Reg;

