import React, { Component } from 'react';
import axios from 'axios';


import './static/css/App.css';

import { Button, Card, CardBody, CardGroup, Col, Container, Form, Input, InputGroup,Row } from 'reactstrap';

class Login extends Component {

    constructor() {

        super();


        this.state = {

            email: '',

           password: ''

        }


        this.password = this.password.bind(this);
        this.email = this.email.bind(this);
        this.login = this.login.bind(this);
    }
    email(event) {

        this.setState({email: event.target.value })
    }
    password(event) {

        this.setState({ password: event.target.value })
    }

    login = async (event) => {

        var data = JSON.stringify({
            email:this.state.email,
            password:this.state.password
            })
        var config = {
          method: 'post',
          url: 'http://localhost/penzi-date-site/login.php',
          headers: { 
            'Content-Type': 'application/json',
          },
          data : data
        };
        
        axios(config)
        .then(function (response) {
          console.log(JSON.stringify(response.data));
        })
        .catch(function (error) {
          console.log(error);
        });
        
    
      }
    
    render() {


        return (

            <div className="app flex-row align-items-center">

                <Container>

                    <Row className="justify-content-center">

                        <Col md="9" lg="7" xl="6">


                            <CardGroup>

                                <Card className="p-2">

                                    <CardBody>

                                        <Form>

                                            <div class="row" className="mb-2 pageheading">

                                                <div class="col-sm-12 btn btn-primary">

                                                     Admin login
                             </div>

                                            </div>

                                            <InputGroup className="mb-3">
                                                <Input type="text" onChange={this.email} placeholder="Enter Email" />

                                            </InputGroup>

                                            <InputGroup className="mb-4">


                                                <Input type="password" onChange={this.password} placeholder="Enter Password" />
                                            </InputGroup>
                                            <Button onClick={this.login} color="success" block>Login</Button>
                                            <p className="forgot-password text-right">
                                               Forgot <a href="#">password?</a>
                                                 </p>
                                            

                                        </Form>
                                    </CardBody>
                                </Card>
                            </CardGroup>

                        </Col>

                    </Row>
                </Container>

            </div>

        );

    }

}


export default Login;