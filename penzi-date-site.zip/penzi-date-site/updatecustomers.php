<?php     
include('QueryManager.php');
$json = file_get_contents('php://input');
$json = json_decode($json);
$conn = new QueryManager();



$conn->update_customers($json,$conn);


