<?php
include('QueryManager.php'); 
define("LOG_FILE","penzi.log");
$json = file_get_contents('php://input');
error_log("\n INFO" . date("Y/m/d H:i:s"). "$json\n",3, LOG_FILE);
$arr_messages = json_decode($json, true);
customermessage($arr_messages);

function customermessage($arr_messages){
    $conn = new QueryManager();
    $messagefromcustomer = $arr_messages['messagefromcustomer'];
    $messagetocustomer= $arr_messages['messagetocustomer'];
    $sendermobile = $arr_messages['sendermobile'];
    $destinationcode = $arr_messages['destinationcode'];
    $message_subject = $arr_messages['message_subject'];
    $messageTimeStamp = $arr_messages['messageTimeStamp'];
    $is_delivered = $arr_messages['is_delivered'];
    
  $sql = "INSERT INTO messages (messagefromcustomer,messagetocustomer, sendermobile, destinationcode, message_subject, messageTimeStamp, is_delivered)
  VALUES ('".$messagefromcustomer."', '".$messagetocustomer."', '".$sendermobile."', '".$destinationcode."', '".$message_subject."', now(), '".$is_delivered."')";


  try {

      $result = $conn->connect()->exec($sql);

      if ($result) {
       http_response_code(200);
       echo json_encode(array('status'=>true, 'status_code'=>200, 'message' => 'Record created successfullly!'));
 } else {
       echo json_encode(array('status'=>false, 'status_code'=>201, 'message' =>'No record created'));
 }
 } catch(Exception $e){
     http_response_code(500);
     echo json_encode(array('status'=>false, 'status_code'=>500, 'message' => "Exception error".$e));


 }
}
