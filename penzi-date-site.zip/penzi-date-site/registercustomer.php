<?php
include('QueryManager.php');

define("LOG_FILE","penzi.log");  
$db = new QueryManager();
$json = file_get_contents('php://input');
error_log("\n INFO" . date("Y/m/d H:i:s")."$json\n", 3, LOG_FILE);
$arr_customers = json_decode($json, true);
//"/register"

registerCustomer($arr_customers);

 function registerCustomer($arr_customers) {
  $name = $arr_customers['name'];
  $age = $arr_customers['age'];
  $sex = $arr_customers['sex'];
  $county = $arr_customers['county'];
  $mobileNumber = $arr_customers['mobileNumber'];
  
 if(preg_match("/^([a-zA-Z']+)$/",$name)){
   $name;
    } else{
       exit('Invalid name given.');
    }

  if($age>=18 && $age<=30){
      if(preg_match('/^[0-9]+$/', $age));{
        $age;
    }
    }else{
       exit('Age must be between 18 to 30');
    }

  if($sex == 'Male'){
    $sex;
    }else if($sex == 'Female'){
    $sex;
    }else{
      exit('Enter a valid gender.');
    }
    
  if(preg_match('/^\+?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$/s', $mobileNumber)) {
      $mobileNumber;
    } else{
      exit('Please enter a valid  mobile Number!');

    }
    
    
  $sql = "INSERT INTO customers(name, age, sex, county, dateCreated, mobileNumber)
              VALUES ('".$name."', '".$age."', '".$sex."', '".$county."',  now(), '".$mobileNumber."')";
  
  try {
    GLOBAL $db;
      $result = $db->connect()->exec($sql); 

      if($result){
        http_response_code(200);
        echo json_encode(array('status'=>true, 'status_code'=>200, 'message' => 'User created successfullly!'));
      }else{
        echo json_encode(array('status'=>false, 'status_code'=>201,'message' => 'User not created successfullly!'));
      }
    
}catch (exception $e) {  
  http_response_code(500);
  echo json_encode(array('status'=>false, 'status_code'=>500,'message' => "exception error".$e));
}
}


 
