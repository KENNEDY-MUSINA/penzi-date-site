<?php
include('QueryManager.php');
$json = file_get_contents('php://input');
$json = json_decode($json);
$conn = new QueryManager();
delete_customers($json,$conn);

function delete_customers($json,$conn){
$id = $json->id;
//var_dump($id);die();
$sql = "DELETE FROM customers WHERE id='$id'";
try {

  $result = $conn->connect()->exec($sql);

  if ($result) {
   http_response_code(200);
   echo json_encode(array('status'=>true, 'status_code'=>200, 'message' => 'customer deleted successfullly!'));
} else {
   echo json_encode(array('status'=>false, 'status_code'=>201, 'message' =>'customer not deleted successfully!'));
}
} catch(Exception $e){
 http_response_code(500);
 echo json_encode(array('status'=>false, 'status_code'=>500, 'message' => "Exception error".$e));
 
}
}
?>

