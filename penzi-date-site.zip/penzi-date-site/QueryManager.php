<?php

class QueryManager
{
  private $conn;
  public  function connect()
  {
    $servername = "localhost";
    $username = "root";
    $password = "";

    try {

      $conn = new PDO("mysql:host=$servername;dbname=penzidb", $username, $password);

      // set the PDO error mode to exception
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      return $conn;
    } catch (PDOException $e) {
      echo "Connection failed: " . $e->getMessage();
      error_log("\n INFO" . date("Y/m/d H:i:s") . "$e\n", 3, LOG_FILE);
    }
  }

  public function update_customers($json, $conn)
  {

    $education = $json->education;
    $profession = $json->profession;
    $marital_status = $json->marital_status;
    $religion = $json->religion;
    $town = $json->town;
    $description = $json->description;
    $mobileNumber = $json->mobileNumber;
     if( preg_match( '/^\+\d(\d{3})(\d{3})(\d{4})$/', $mobileNumber)){
       $mobileNumber;
     }else{
       exit('Please enter valid mobile number');
     }
    
    $sql = "UPDATE customers SET education='$education', profession='$profession',
     marital_status='$marital_status', religion='$religion', town='$town', description='$description'
    WHERE mobileNumber='$mobileNumber'";
    $affectedRows = $conn->connect()->exec($sql);
    // var_dump($affectedRows);die();
    if ($affectedRows > 0) {

      echo $affectedRows . "records updated successfully!";
      return true;
    } else {

      echo "nothhing to update!";
      return false;
      
    }

    $conn = null;
  }

public function update_matchquery($json, $conn)
  {

    $listofmatchedids = $json->listofmatchedids;
    $listofmatchedsendids = $json->listofmatchedsendids;
    $listofmatchednotsendids = $json->listofmatchednotsendids;
    $whomobile = $json->whomobile;
    
    $sql = "UPDATE match_queries SET listofmatchedids='$listofmatchedids', listofmatchedsendids='$listofmatchedsendids',
     listofmatchednotsendids='$listofmatchednotsendids'
    WHERE whomobile='$whomobile'";
    $affectedRows = $conn->connect()->exec($sql);
    // var_dump($affectedRows);die();
    if ($affectedRows > 0) {

      echo $affectedRows . "records updated successfully!";
      return true;
    } else {

      echo "nothhing to update!";
      return false;
      
    }

    $conn = null;
  }
  function _select($sql, $params)
  {
    $username = 'root';
    $password = '';
    $database = 'penzidb';
    $host = 'localhost';

    $res = array();
    try {
      $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $stmt = $pdo->prepare($sql);
      $stmt->execute($params);
      $res = $stmt->fetchAll();
    } catch (PDOException $error) {

      error_log("\n INFO" . date("Y/m/d H:i:s")."$error\n", 3, LOG_FILE);

    }
    return $res;
  }
} 
	

	 
