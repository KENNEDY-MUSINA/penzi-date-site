<?php
//echo "Hello world";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "penzidb";
//include_once('QueryManager.php');

//Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
//Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM messages";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) >1) {
  // output data of each row
  echo json_encode(mysqli_fetch_assoc($result));
  // while($row = mysqli_fetch_assoc($result)) {
   // echo "id: " . $row["id"]. "name: " . $row["name"]. "age: " . $row["age"]. "<br>";
  // }
} else {
  echo "0 results";
}

mysqli_close($conn);



    // if(empty($_POST['name'])){
    // $name = $_POST['name'];
    // $name = trim(htmlspecialchars($_POST['name']));
    //if(empty($_POST['age'])){
      //$age = $_POST['age'];
          //$age = !filter_var($age, FILTER_VALIDATE_INT);

    
    
