<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Authorization, Accept,charset,boundary,Content-Length');    
include('QueryManager.php');
define("LOG_FILE","penzi.log");



$db = new QueryManager();
$json = file_get_contents('php://input');
error_log("\n INFO". date("Y/m/d H:i:s"). "$json\n", 3, LOG_FILE );
$arr_user = json_decode($json,true);
userregistration($arr_user);

function userregistration($arr_user){
$conn = new QueryManager();   
$first_name = $arr_user['first_name'];
$last_name = $arr_user['last_name'];
$email = $arr_user['email'];
$password = md5($arr_user['password']);
//$last_login = $arr_user['last_login'];
//$account_status = $arr_user['account_status'];

if(preg_match("/^([a-zA-Z']+)$/",$first_name)){
    $first_name;
     } else{
      http_response_code(201);
        exit(json_encode(array('status'=>false, 'status_code'=>201, 'message' =>'please enter your first name')));
     }
if(preg_match("/^([a-zA-Z']+)$/",$last_name)){
        $last_name;
} else{
       http_response_code(201);

      exit(json_encode(array('status'=>false, 'status_code'=>201, 'message' =>'please enter your last name')));

      }     
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  http_response_code(201);
    exit(json_encode(array('status'=>false, 'status_code'=>201, 'message' =>'Invalid email'))); 
}
if(preg_match('/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]{8,12}$/', $password)) {
http_response_code(201);
exit( json_encode(array('status'=>false, 'status_code'=>201, 'message' =>  'Password must contain 6 characters of letters, numbers and 
 at least one special character.')));
}


$sql = "INSERT INTO user_login(first_name, last_name, email, password)
VALUES ('".$first_name."', '".$last_name."', '".$email."', '".$password."' )";

try {
GLOBAL $db;
$result = $db->connect()->exec($sql); 

if($result){
http_response_code(200);
echo json_encode(array('status'=>true, 'status_code'=>200, 'message' => 'User registered successfullly!'));
}else{
echo json_encode(array('status'=>false, 'status_code'=>201,'message' => 'User not registered successfullly!'));
}

}catch (exception $e) {  
http_response_code(500);
echo json_encode(array('status'=>false, 'status_code'=>500,'message' => "exception error".$e));
}
}







