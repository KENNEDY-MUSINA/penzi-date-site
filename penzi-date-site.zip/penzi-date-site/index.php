<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script>href="%PUBLIC_URL%/favicon.ico" </script>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#000000" />
    <meta
      name="description"
      content="Web site created using create-react-app"
    />
    <script>href="%PUBLIC_URL%/logo192.png" </script>
    <script>href="%PUBLIC_URL%/manifest.json" </script>
    

</head>
<body>
 <div id = 'root'></div>
 <script  type="text/babel">

class App extends React.Component {
  state = {
    UserDetails: []
  }
  render() {
    return (
        <React.Fragment>
        <h1>Admin Registration</h1>
        <table border='1' width='100%' >
        <tr>
            <th>first_name</th>
            <th>last_name</th>
            <th>email</th>
            <th>password</th>
            <th>last_login</th>
            <th>account_status</th>     
        </tr>

        {this.state.contacts.map((contact) => (
        <tr>
            <td>{ UserDetails.first_name}</td>
            <td>{ UserDetails.last_name }</td>
            <td>{ UserDetails.email}</td>
            <td>{ UserDetails.password }</td>
            <td>{ UserDetails.last_login}</td>
            <td>{ UserDetails.account_status}</td>
        </tr>
        ))}
        </table>
        </React.Fragment>
    );
  }
}

ReactDOM.render(<App />, document.getElementById('root'));
</script>

</body>
</html>
