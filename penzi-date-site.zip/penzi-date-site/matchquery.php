<?php
include('QueryManager.php');
define("LOG_FILE","penzi.log");
$json = file_get_contents('php://input');
error_log("\n INFO" . date("Y/m/d H:i:s"). "$json\n",3, LOG_FILE);
$arr_match = json_decode($json, true);
matchquery($arr_match);

function matchquery($arr_match){
    $conn = new QueryManager();
    $userquery = $arr_match['userquery'];
    $whomobile = $arr_match['whomobile'];
    $dateSend = $arr_match['dateSend'];
    $listofmatchedids = $arr_match['listofmatchedids'];
    $listofmatchedsendids = $arr_match['listofmatchedsendids'];
    $listofmatchednotsendids= $arr_match['listofmatchednotsendids'];
    
  $sql = "INSERT INTO match_queries (userquery, whomobile, dateSend, listofmatchedids, listofmatchedSendids, listofmatchednotsendids)
  VALUES ('".$userquery."', '".$whomobile."', now(), '".$listofmatchedids."', '".$listofmatchedsendids."', '".$listofmatchednotsendids."')";
    

  try {

      $result = $conn->connect()->exec($sql);

      if ($result) {
       http_response_code(200);
       echo json_encode(array('status'=>true, 'status_code'=>200, 'message' => 'Record inserted successfullly!'));
 } else {
       echo json_encode(array('status'=>false, 'status_code'=>201, 'message' =>'No record created'));
 }
 } catch(Exception $e){
     http_response_code(500);
     echo json_encode(array('status'=>false, 'status_code'=>500, 'message' => "Exception error".$e));
     error_log("\n INFO" . date("Y/m/d H:i:s") . "$e\n", 3, LOG_FILE);



 }
}

