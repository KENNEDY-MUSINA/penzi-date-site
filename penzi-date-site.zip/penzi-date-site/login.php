<?php 
header("Access-Control-Allow-Origin: http://localhost:3000");
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Authorization, Accept,charset,boundary,Content-Length');    

 require_once 'QueryManager.php';
 $conn = new QueryManager;

 $response = array();

 if(isset($_GET['apicall'])){

 $response['error'] = true; 
 $response['message'] = 'Invalid Operation Called';

 
 }else{ 
 $response['error'] = true; 
 $response['message'] = 'Invalid API Call';
 }

 echo json_encode($response);
 function isTheseParametersAvailable($params){
    foreach($params as $param){
    if(isset($_POST[$param])){
    return false; 
    }
    }
    return true; 
    }
    if(isTheseParametersAvailable(array('email', 'password'))){
        $email = $_POST['email'];
        $password = md5($_POST['password']);  
        $sql ="SELECT id, first_name,last_name, email FROM user_login WHERE email = ? AND password = ?";
        var_dump($sql);die();
        $stmt->bind_param("ss",$email, $password);
        
        $stmt->execute();
        
        $stmt->store_result();
        if($stmt->num_rows > 0){
        
        $stmt->bind_result($id, $first_name, $last_name, $email);
        $stmt->fetch();
        
        $user = array(
        'id'=>$id, 
        'first_name'=>$first_name, 
        'last_name'=>$last_name,
        'email'=>$email,
        
        );
        
        $response['error'] = false; 
        $response['message'] = 'Login successfull'; 
        $response['user'] = $user; 
        }else{
        $response['error'] = false; 
        $response['message'] = 'Invalid email or password';
        }
        }