<?php 

require('QueryManager.php');
$json = file_get_contents('php://input');
$json = json_decode($json);
$conn = new QueryManager();
define('LOG_FILE', "penzi.log");
error_log("\n INFO" . date("Y/m/d H:i:s") . "$json\n", 3, LOG_FILE);


$name = null;
$sql = "SELECT * FROM match_queries";
try {
  $params = array(
    ':name' => $name,
  );
  $result = $conn->_select($sql,$params);
  var_dump($result); die();

  if ($result) {
   echo json_encode(mysqli_fetch_assoc($result));
   http_response_code(200);
   echo json_encode(array('status'=>true, 'status_code'=>200, 'customers' => 'Records selected successfullly!'));
} else {

   echo json_encode(array('status'=>false, 'status_code'=>201, 'customers' =>'No record created'));
}
} catch(Exception $e){
 http_response_code(500);
 echo json_encode(array('status'=>false, 'status_code'=>500, 'customers' => "Exception error".$e));
 error_log("\n INFO" . date("Y/m/d H:i:s") . "$e\n", 3, LOG_FILE);
}
